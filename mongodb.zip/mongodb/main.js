const express=require('express')
const mongoose= require('mongoose')


let app =express()
app.use(express.json())


async function createConnection(){
    await
    mongoose.connect('mongodb+srv://paritosh:paritosh1234@paritosh.pvme14k.mongodb.net/?retryWrites=true&w=majority&appName=paritosh')
}
createConnection()
.then(()=>{
    console.log("database connected")
})
.catch((err)=>{
    console.log(err)
})


let userSchema = new mongoose.Schema({
    name: {
        type: String,
        require: true,
    },
    age:Number,
    address:String
}, {
    timestamps: true
})

let userInfo = new mongoose.model('userInfo', userSchema)

app.post('/submit', async (req,res)=>{
    let finalData = new userInfo({
        name: req.body.name,
        age: req.body.age,
        address: req.body.address,
    })
    finalData.save()
    .then(()=>{
        res.send("data saved")
    })
    .catch((err)=>{
        console.log(err)
    })

})

app.get('/getData', async (req,res)=>{
    let result = await userInfo.find({})
    res.json(result)
})

app.delete('/deleteData/:id', async(req, res)=>{
    let id =req.params.id
    let result = await userInfo.findByIdAndDelete({_id:id})
    res.send("data deleted")
})

app.put('/updateData/:id', async (req, res)=>{
    let id = req.params.id
    let newData = req.body
    await userInfo.findByIdAndUpdate(id, newData, {new : true})
    res.send("data updated")
})


app.listen(3000, ()=>{
    console.log("server is running")
})

